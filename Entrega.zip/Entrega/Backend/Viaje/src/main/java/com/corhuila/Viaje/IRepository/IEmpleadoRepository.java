package com.corhuila.Viaje.IRepository;

import com.corhuila.Viaje.Entity.Empleado;
import org.springframework.data.jpa.repository.JpaRepository;

public interface IEmpleadoRepository extends JpaRepository<Empleado, Integer> {
}
