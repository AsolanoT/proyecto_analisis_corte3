package com.corhuila.Viaje;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ViajeApplicationTests {

	@Test
	void contextLoads() {
	}

}
